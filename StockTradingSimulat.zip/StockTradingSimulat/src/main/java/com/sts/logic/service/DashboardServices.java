package com.sts.logic.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sts.data.entity.Bank;
import com.sts.data.entity.RoundUser;
import com.sts.data.entity.User;
import com.sts.data.repository.BankRepository;
import com.sts.data.repository.RoundUserRepository;
import com.sts.data.repository.UserRepository;
import com.sts.logic.domain.RoundUserDomain;
import com.sts.logic.domain.UserBankDomain;

@Service
public class DashboardServices {

	private UserRepository userRepository;
	private BankRepository bankRepository;
	private RoundUserRepository roundUserRepository;

	@Autowired
	public DashboardServices(UserRepository userRepository, BankRepository bankRepository,
			RoundUserRepository roundUserRepository) {
		super();
		this.userRepository = userRepository;
		this.bankRepository = bankRepository;
		this.roundUserRepository = roundUserRepository;
	}
	

	// Get User Bank Data

	public UserBankDomain getUserBankData(String userName) {

		User user = this.userRepository.findByUserName(userName);
		Bank bank = this.bankRepository.findByUser(user);

		UserBankDomain userBankDomain = new UserBankDomain();

		userBankDomain.setUserName(userName);
		userBankDomain.setUserId(user.getUserId());
		userBankDomain.setBankId(bank.getBankId());
		userBankDomain.setBankAmount(bank.getBankAmount());
		return userBankDomain;
	}

	// Get All Rounds of wining Users

		public List<RoundUserDomain> getWiningUsers() {

			List<RoundUserDomain> roundUserDomains = new ArrayList<>();
			Iterable<RoundUser> allRounds = this.roundUserRepository.findByUserState("w");
			allRounds.forEach(round -> {
				RoundUserDomain roundUserDomain = new RoundUserDomain();
				roundUserDomain.setRoundUserId(round.getRoundUserId());
				roundUserDomain.setRoundId(round.getRound().getRoundId());
				roundUserDomain.setUserId(round.getUser().getUserId());
				roundUserDomain.setUserName(round.getUser().getUserName());
				roundUserDomain.setUserState(round.getUserState());
				roundUserDomains.add(roundUserDomain);
			});

			return roundUserDomains;
		}

	// Get Online Players List

	public List<User> getPlayersOnline(String userName) {
		List<User> users = new ArrayList<>();
		Iterable<User> allUsersOnline = this.userRepository.findByOnline(true);
		allUsersOnline.forEach(user -> {
			if (!userName.equals(user.getUserName())) {
				users.add(user);
			}
		});

		return users;
	}

}
