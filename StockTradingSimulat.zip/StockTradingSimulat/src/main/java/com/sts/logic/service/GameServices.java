package com.sts.logic.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sts.data.entity.Bank;
import com.sts.data.entity.Company;
import com.sts.data.entity.Round;
import com.sts.data.entity.RoundUser;
import com.sts.data.entity.Transaction;
import com.sts.data.entity.Turn;
import com.sts.data.entity.TurnCompany;
import com.sts.data.entity.User;
import com.sts.data.entity.UserTurn;
import com.sts.data.repository.BankRepository;
import com.sts.data.repository.CompanyRepository;
import com.sts.data.repository.RoundRepository;
import com.sts.data.repository.RoundUserRepository;
import com.sts.data.repository.SectorRepository;
import com.sts.data.repository.TransactionRepository;
import com.sts.data.repository.TurnCompanyRepository;
import com.sts.data.repository.TurnRepository;
import com.sts.data.repository.UserRepository;
import com.sts.data.repository.UserTurnRepository;
import com.sts.logic.domain.CompanyDomain;
import com.sts.logic.domain.EventDomain;
import com.sts.logic.domain.GameRunDomain;
import com.sts.logic.domain.TurnDomain;
import com.sts.logic.domain.WinnerDomain;

@Service
public class GameServices {

	private SectorRepository sectorRepository;
	private CompanyRepository companyRepository;
	private UserTurnRepository userTurnRepository;
	private BankRepository bankRepository;
	private RoundUserRepository roundUserRepository;
	private TransactionRepository transactionRepository;
	private UserRepository userRepository;
	private RoundRepository roundRepository;
	private TurnRepository turnRepository;
	private TurnCompanyRepository turnCompanyRepository;
	private double profitForWiner = 0;
	private User winingUser;
	public List<User> user;

	private static int stmc = 0;
	private static int rmc = 0;
	private static int gtmc = 0;
	private static int ec = 0;
	private static int eventOccurPossibility = 0;
	private static List<EventDomain> eventDomains = new ArrayList<>();
	private static EventDomain eventDomain = new EventDomain();

	@Autowired
	public GameServices(SectorRepository sectorRepository, CompanyRepository companyRepository,
			UserTurnRepository userTurnRepository, BankRepository bankRepository,
			RoundUserRepository roundUserRepository, TransactionRepository transactionRepository,
			UserRepository userRepository, RoundRepository roundRepository, TurnRepository turnRepository,
			TurnCompanyRepository turnCompanyRepository) {
		super();
		this.sectorRepository = sectorRepository;
		this.companyRepository = companyRepository;
		this.userTurnRepository = userTurnRepository;
		this.bankRepository = bankRepository;
		this.roundUserRepository = roundUserRepository;
		this.transactionRepository = transactionRepository;
		this.userRepository = userRepository;
		this.roundRepository = roundRepository;
		this.turnRepository = turnRepository;
		this.turnCompanyRepository = turnCompanyRepository;

	}

	// Game Run
	public List<GameRunDomain> run(int tempTurn, String userName, int roundId, int sectorId) {

		List<GameRunDomain> gameRunDomains = new ArrayList<>();

		Iterable<Company> companies = this.companyRepository
				.findBySector(this.sectorRepository.findBySectorId(sectorId));
		companies.forEach(company -> {
			GameRunDomain gameRunDomain = new GameRunDomain();
			gameRunDomain.setCompanyId(company.getCompanyId());
			gameRunDomain.setCompanyName(company.getCompanyName());
			gameRunDomain.setRoundId(roundId);
			gameRunDomain.setUserName(userName);
			gameRunDomain.setTempTurnId(tempTurn);

			for (int j = 0; j < (tempTurn); j++) {
				TurnCompany turnCompany = this.turnCompanyRepository.findByTurnAndCompany((this.turnRepository
						.findByRoundAndTurnTempId(this.roundRepository.findByRoundId(roundId), (tempTurn))), company);
				switch (j + 1) {
				case 1:
					gameRunDomain.setSharePriceTurn1(turnCompany.getStockPrice());
					break;
				case 2:
					gameRunDomain.setSharePriceTurn2(turnCompany.getStockPrice());
					break;
				case 3:
					gameRunDomain.setSharePriceTurn3(turnCompany.getStockPrice());
					break;
				case 4:
					gameRunDomain.setSharePriceTurn4(turnCompany.getStockPrice());
					break;
				case 5:
					gameRunDomain.setSharePriceTurn5(turnCompany.getStockPrice());
					break;
				case 6:
					gameRunDomain.setSharePriceTurn6(turnCompany.getStockPrice());
					break;
				case 7:
					gameRunDomain.setSharePriceTurn7(turnCompany.getStockPrice());
					break;
				case 8:
					gameRunDomain.setSharePriceTurn8(turnCompany.getStockPrice());
					break;
				case 9:
					gameRunDomain.setSharePriceTurn9(turnCompany.getStockPrice());
					break;
				case 10:
					gameRunDomain.setSharePriceTurn10(turnCompany.getStockPrice());
					break;
				}
			}
			gameRunDomains.add(gameRunDomain);

		});

		return gameRunDomains;
	}

//	public List<GameRunDomain> sharesNotSold(int tempTurn, String userName, int roundId, int sectorId) {
//		List<GameRunDomain> gameRunDomains = new ArrayList<>();
//
////		Iterable<Company> companies = this.companyRepository
////				.findBySectorAndUserTurns(this.sectorRepository.findBySectorId(sectorId), this.userTurnRepository.findBy);
//
//		return gameRunDomains;
//	}

	// Buy Shares
	public boolean buyShares(int roundId, int companyId, String userName, int tempTurn, int units) {

		// Check Bank Value Enough
		double sPrice = (this.turnCompanyRepository.findByTurnAndCompany(
				(this.turnRepository.findByRoundAndTurnTempId(this.roundRepository.findByRoundId(roundId), (tempTurn))),
				this.companyRepository.findByCompanyId(companyId))).getStockPrice();
		double amount = (sPrice * units);
		Bank bank = this.bankRepository.findByUser(this.userRepository.findByUserName(userName));
		double bankAmount = bank.getBankAmount();
		if (amount <= bankAmount) {

			// Save to UserTurn
			UserTurn userTurn = new UserTurn();
			userTurn.setCompany(this.companyRepository.findByCompanyId(companyId));
			userTurn.setStockPrice(sPrice);
			userTurn.setTradingType("b");
			userTurn.setTurn(this.turnRepository.findByTurnTempIdAndRound(tempTurn, this.roundRepository.findByRoundId(roundId)));
			userTurn.setUnit(units);
			userTurn.setUser(this.userRepository.findByUserName(userName));
//			userTurn.setSell(false);
			this.userTurnRepository.save(userTurn);

			// Save to RoundUser
			Round round = this.roundRepository.findByRoundId(roundId);
			User user = this.userRepository.findByUserName(userName);
			RoundUser roundUser = this.roundUserRepository.findByRoundAndUser(round, user);
			roundUser.setBoughtValue(((roundUser.getBoughtValue()) + amount));
			this.roundUserRepository.save(roundUser);

			// Subtract from Bank Account
			bank.setBankAmount(bankAmount - amount);
			this.bankRepository.save(bank);

			// Set Transaction
			Transaction transaction = new Transaction();
			transaction.setBank(bank);
			transaction.setTransactionAmount(amount);
			transaction.setTransactionType("w");
			this.transactionRepository.save(transaction);

			// Send Confirmation
			return true;

		} else {
			return false;
		}
	}

	// Sell Shares
	public boolean sellShares(int roundId, int companyId, int turnId, String userName, double sharePrice, int units) {

		// Save to UserTurn
		UserTurn userTurn = new UserTurn();
		userTurn.setCompany(this.companyRepository.findByCompanyId(companyId));
		userTurn.setStockPrice(sharePrice);
		userTurn.setTradingType("s");
		userTurn.setTurn(this.turnRepository.findByTurnId(turnId));
		userTurn.setUnit(units);
		userTurn.setUser(this.userRepository.findByUserName(userName));
		this.userTurnRepository.save(userTurn);

		// Save to RoundUser
		double amount = (sharePrice * units);
		Round round = this.roundRepository.findByRoundId(roundId);
		User user = this.userRepository.findByUserName(userName);
		RoundUser roundUser = this.roundUserRepository.findByRoundAndUser(round, user);
		roundUser.setSoldValue(((roundUser.getSoldValue()) + amount));
		this.roundUserRepository.save(roundUser);

		// Add to Bank Account
		Bank bank = this.bankRepository.findByUser(this.userRepository.findByUserName(userName));
		double bankAmount = bank.getBankAmount();
		bank.setBankAmount(bankAmount + amount);
		this.bankRepository.save(bank);

		// Set Transaction
		Transaction transaction = new Transaction();
		transaction.setBank(bank);
		transaction.setTransactionAmount(amount);
		transaction.setTransactionType("d");
		this.transactionRepository.save(transaction);

		// Send Confirmation
		return true;
	}

	// Find Winner
	public List<WinnerDomain> winner(int roundId) {
		List<WinnerDomain> winnerDomains = new ArrayList<>();
		List<RoundUser> roundUsers = this.roundUserRepository.findByRound(this.roundRepository.findByRoundId(roundId));
		roundUsers.forEach(roundUser -> {
			if ((roundUser.getSoldValue() - roundUser.getBoughtValue()) >= profitForWiner) {
				profitForWiner = roundUser.getSoldValue() - roundUser.getBoughtValue();
				winingUser = roundUser.getUser();
			}
		});
		roundUsers.forEach(roundUser -> {
			if (roundUser.getUser().equals(winingUser)) {
				roundUser.setUserState("w");
				this.roundUserRepository.save(roundUser);
			}
		});
		profitForWiner = 0;
		roundUsers.forEach(roundUser -> {
			WinnerDomain winnerDomain = new WinnerDomain();
			winnerDomain.setUserId(roundUser.getUser().getUserId());
			winnerDomain.setRoundId(roundId);
			winnerDomain.setUserName(roundUser.getUser().getUserName());
			winnerDomain.setProfit(roundUser.getSoldValue() - roundUser.getBoughtValue());
			winnerDomain.setState(roundUser.getUserState());
			winnerDomains.add(winnerDomain);
		});
		return winnerDomains;
	}

	// Start A Game
	public int gameStart(List<String> userNames) {
		Round round = new Round();
		this.roundRepository.save(round);
		round = this.roundRepository.findFirstByOrderByRoundIdDesc();
		// gameDomain.setRoundId(round.getRoundId());

		this.saveRoundUsers(userNames, round);
		this.saveRoundTurns(this.roundTurnsValues(), round);
		return round.getRoundId();
	}

	private void saveRoundUsers(List<String> usernames, Round round) {
		usernames.forEach(userInList -> {
			User user = this.userRepository.findByUserName(userInList);
			RoundUser roundUser = new RoundUser();
			roundUser.setRound(round);
			roundUser.setUser(user);
			roundUser.setUserState("l");
			roundUser.setBoughtValue(0);
			roundUser.setSoldValue(0);
			this.roundUserRepository.save(roundUser);
			user.setOnline(false);
			this.userRepository.save(user);
		});
	}

	private void saveRoundTurns(List<TurnDomain> turnDomainList, Round round) {
		List<TurnDomain> turnDomains = turnDomainList;
		turnDomains.forEach(turnDomain -> {
			Turn turn = new Turn();
			turn.setRound(round);
			turn.setTurnTempId(turnDomain.getTempTurnId());
			this.turnRepository.save(turn);
			turnDomain.getCompanyDomains().forEach(companyDoamin -> {
				TurnCompany turnCompany = new TurnCompany();
				turnCompany.setCompany(this.companyRepository.findByCompanyId(companyDoamin.getCompanyId()));
				turnCompany.setTurn(this.turnRepository.findFirstByOrderByTurnIdDesc());
				turnCompany.setStockPrice(companyDoamin.getLastStockPrice());
				this.turnCompanyRepository.save(turnCompany);
			});
		});
	}

	// Get New Round Turn Values

	public List<TurnDomain> roundTurnsValues() {
		List<TurnDomain> turnDomains = new ArrayList<>();
		List<CompanyDomain> companyDomains = new ArrayList<>();
		for (int i = 0; i < 10; i++) {
			this.valueSTMC();
			this.valueGTMC();
			this.eventOccurTurn(i);
			this.removeEvent(i);
			this.eventValueCalculate();
			TurnDomain turnDomain = new TurnDomain();
			turnDomain.setTempTurnId(i + 1);
			if (i == 0) {
				Iterable<Company> allCompanies = this.companyRepository.findAll();
				allCompanies.forEach(company -> {
					CompanyDomain companyDomain = new CompanyDomain();
					companyDomain.setCompanyId(company.getCompanyId());
					companyDomain.setCompanyName(company.getCompanyName());
					this.valueRMC();
					companyDomain.setLastStockPrice(this.calculatedStockPrice(company.getLastStockPrice()));
					companyDomains.add(companyDomain);
				});
			} else {
				// companyDomains.forEach(s -> System.out.println(s.getLastStockPrice()));
				companyDomains.forEach(company -> {
					this.valueRMC();
					company.setLastStockPrice(this.calculatedStockPrice(company.getLastStockPrice()));
				});
				// companyDomains.forEach(s -> System.out.println(s.getLastStockPrice()));
			}
			turnDomain.setCompanyDomains(companyDomains);
			turnDomains.add(turnDomain);
		}
		this.clearECValueAndEventDomain();
		return turnDomains;
	}

	private void clearECValueAndEventDomain() {
		eventDomains.removeAll(eventDomains);
		ec = 0;
		eventOccurPossibility = 0;
	}

	private double calculatedStockPrice(double lastStockPrice) {
		double newStockPrice = lastStockPrice;
		double y = this.yValue();
		newStockPrice = Math.round((lastStockPrice + (lastStockPrice * y)));
		return newStockPrice;
	}

	private double yValue() {
		double y = rmc + stmc + gtmc + ec;
		y = (y / 100);
		// System.out.println(y);
		if (y > 0) {
			return y;
		} else {
			return 0;
		}
	}

	private void valueRMC() {
		rmc = this.randomValue(+2, -2);
	}

	private void valueSTMC() {
		int[] valueRange = new int[] { -3, -3, -2, -2, -1, -1, 0, 0, 1, 2, 3 };
		Random random = new Random();
		stmc = valueRange[random.nextInt(valueRange.length)];
	}

	private void valueGTMC() {
		int[] valueRange = new int[] { -3, -3, -2, -2, -1, -1, 0, 0, 1, 2, 3 };
		Random random = new Random();
		gtmc = valueRange[random.nextInt(valueRange.length)];
	}

	private void eventValueCalculate() {
		ec = 0;
		eventDomains.forEach(event -> {
			ec += event.getEventValue();
		});
	}

	private void removeEvent(int turn) {
		List<EventDomain> eventDomainsToRemove = new ArrayList<>();
		eventDomains.forEach(event -> {
			if (turn == event.getEventEnd()) {
				eventDomainsToRemove.add(event);
			}
		});
		eventDomains.removeAll(eventDomainsToRemove);
	}

	private void eventOccurTurn(int turn) {
		if (eventOccurPossibility == 0) {
			eventOccurPossibility += 1;
		} else if (eventOccurPossibility == 10) {
			this.setEventTypeEnd(turn);
			eventOccurPossibility = 0;
		} else {
			int[] valueRange = new int[] { 0, 1 };
			Random random = new Random();
			int value = valueRange[random.nextInt(valueRange.length)];
			if (value == 1) {
				this.setEventTypeEnd(turn);
				eventOccurPossibility = 0;
			} else if (value == 0) {
				eventOccurPossibility += 1;
			}
		}
	}

	private void setEventTypeEnd(int turn) {
		// 0 = Sector Event & 1 = Stock Event
		int[] valueRange = new int[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
				1, 1, 1 };
		Random random = new Random();
		int value = valueRange[random.nextInt(valueRange.length)];
		if (value == 0) {
			eventDomain.setEventEnd((this.randomValue(5, 2)) + turn);
			this.sectorEvent();
		} else if (value == 1) {
			eventDomain.setEventEnd((this.randomValue(7, 1)) + turn);
			this.stockEvent();
		}
	}

	private void sectorEvent() {
		// 0 = BUST Event / 1 = BOOM Event
		int[] valueRange = new int[] { 0, 1 };
		Random random = new Random();
		int value = valueRange[random.nextInt(valueRange.length)];
		if (value == 0) {
			eventDomain.setEventValue(this.randomValue(5, 1));
			eventDomains.add(eventDomain);
		} else if (value == 1) {
			eventDomain.setEventValue(this.randomValue(-1, -5));
			eventDomains.add(eventDomain);
		}
	}

	private void stockEvent() {
		// 0 = Profit Warning Event / 1 = Take Over Event / 2 = Scandle Event
		int[] valueRange = new int[] { 0, 0, 1, 2 };
		Random random = new Random();
		int value = valueRange[random.nextInt(valueRange.length)];
		if (value == 0) {
			eventDomain.setEventValue(this.randomValue(3, 2));
			eventDomains.add(eventDomain);
		} else if (value == 1) {
			eventDomain.setEventValue(this.randomValue(-1, -5));
			eventDomains.add(eventDomain);
		} else if (value == 2) {
			eventDomain.setEventValue(this.randomValue(-3, -6));
			eventDomains.add(eventDomain);
		}
	}

	private int randomValue(int max, int min) {
		int rValue = (int) ((Math.random() * ((max - min) + 1)) + min);
		return rValue;
	}
}
