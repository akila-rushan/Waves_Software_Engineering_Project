package com.sts.logic.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sts.data.entity.Company;
import com.sts.data.entity.Sector;
import com.sts.data.repository.CompanyRepository;
import com.sts.data.repository.SectorRepository;
import com.sts.logic.domain.CompanyDomain;
import com.sts.logic.domain.SectorDomain;

@Service
public class CompanyServices {

	private CompanyRepository companyRepository;
	private SectorRepository sectorRepository;
	
	@Autowired
	public CompanyServices(CompanyRepository companyRepository, SectorRepository sectorRepository) {
		super();
		this.companyRepository = companyRepository;
		this.sectorRepository = sectorRepository;
	}

	// Get Company Data

	public List<Company> getAllCompany() {
		List<Company> companies = new ArrayList<>();
		Iterable<Company> allCompanies = this.companyRepository.findAll();
		allCompanies.forEach(company -> {
			companies.add(company);
		});

		return companies;
	}
	
	// Get All Company Data group by Sector
	
	public List<SectorDomain> getAllCompaniesGroupSector() {
		
		List<SectorDomain> sectorDomains = new ArrayList<>();
		Iterable<Sector> allSectors = this.sectorRepository.findAll();
		allSectors.forEach(sector -> {
			SectorDomain sectorDomain = new SectorDomain();
			sectorDomain.setSectorId(sector.getSectorId());
			sectorDomain.setSectorName(sector.getSectorName());
			List<CompanyDomain> companyDomains = new ArrayList<>();
			Iterable<Company> allCompanies = this.companyRepository.findBySector(sector);
			allCompanies.forEach(company -> {
				CompanyDomain companyDomain = new CompanyDomain();
				companyDomain.setCompanyId(company.getCompanyId());
				companyDomain.setCompanyName(company.getCompanyName());
				companyDomain.setLastStockPrice(company.getLastStockPrice());
				companyDomains.add(companyDomain);
			});
			sectorDomain.setCompanyDomains(companyDomains);
			sectorDomains.add(sectorDomain);
		});
		
		return sectorDomains;
	}

}
