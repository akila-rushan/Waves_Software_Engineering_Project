package com.sts.logic.domain;

public class CompanyDomain {

	private int companyId;
	private String companyName;
	private double lastStockPrice;

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public double getLastStockPrice() {
		return lastStockPrice;
	}

	public void setLastStockPrice(double lastStockPrice) {
		this.lastStockPrice = lastStockPrice;
	}

}
