package com.sts.logic.domain;

public class RoundUserDomain {

	private int userId;
	private int roundId;
	private int roundUserId;
	private String userState;
	private String userName;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getRoundId() {
		return roundId;
	}

	public void setRoundId(int roundId) {
		this.roundId = roundId;
	}

	public int getRoundUserId() {
		return roundUserId;
	}

	public void setRoundUserId(int roundUserId) {
		this.roundUserId = roundUserId;
	}

	public String getUserState() {
		return userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
