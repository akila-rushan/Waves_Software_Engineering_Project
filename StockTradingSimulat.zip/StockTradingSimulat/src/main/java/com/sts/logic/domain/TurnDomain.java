package com.sts.logic.domain;

import java.util.List;

public class TurnDomain {

	private int tempTurnId;
	private List<CompanyDomain> companyDomains;

	public int getTempTurnId() {
		return tempTurnId;
	}

	public void setTempTurnId(int tempTurnId) {
		this.tempTurnId = tempTurnId;
	}

	public List<CompanyDomain> getCompanyDomains() {
		return companyDomains;
	}

	public void setCompanyDomains(List<CompanyDomain> companyDomains) {
		this.companyDomains = companyDomains;
	}

}
