package com.sts.logic.domain;

import java.util.List;

public class SectorDomain {

	private int sectorId;
	private String sectorName;
	private List<CompanyDomain> companyDomains;

	public int getSectorId() {
		return sectorId;
	}

	public void setSectorId(int sectorId) {
		this.sectorId = sectorId;
	}

	public String getSectorName() {
		return sectorName;
	}

	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}

	public List<CompanyDomain> getCompanyDomains() {
		return companyDomains;
	}

	public void setCompanyDomains(List<CompanyDomain> companyDomains) {
		this.companyDomains = companyDomains;
	}

}
