package com.sts.logic.domain;

public class UsersForNewGame {

	private String UserName;

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

}
