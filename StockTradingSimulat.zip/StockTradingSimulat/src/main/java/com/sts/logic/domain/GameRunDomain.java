package com.sts.logic.domain;

public class GameRunDomain {
	private int companyId;
	private String companyName;
	private int roundId;
	private int tempTurnId;
	private String userName;
	private int units;
	private double sharePriceTurn1;
	private double sharePriceTurn2;
	private double sharePriceTurn3;
	private double sharePriceTurn4;
	private double sharePriceTurn5;
	private double sharePriceTurn6;
	private double sharePriceTurn7;
	private double sharePriceTurn8;
	private double sharePriceTurn9;
	private double sharePriceTurn10;

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public int getRoundId() {
		return roundId;
	}

	public void setRoundId(int roundId) {
		this.roundId = roundId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public double getSharePriceTurn1() {
		return sharePriceTurn1;
	}

	public void setSharePriceTurn1(double sharePriceTurn1) {
		this.sharePriceTurn1 = sharePriceTurn1;
	}

	public double getSharePriceTurn2() {
		return sharePriceTurn2;
	}

	public void setSharePriceTurn2(double sharePriceTurn2) {
		this.sharePriceTurn2 = sharePriceTurn2;
	}

	public double getSharePriceTurn3() {
		return sharePriceTurn3;
	}

	public void setSharePriceTurn3(double sharePriceTurn3) {
		this.sharePriceTurn3 = sharePriceTurn3;
	}

	public double getSharePriceTurn4() {
		return sharePriceTurn4;
	}

	public void setSharePriceTurn4(double sharePriceTurn4) {
		this.sharePriceTurn4 = sharePriceTurn4;
	}

	public double getSharePriceTurn5() {
		return sharePriceTurn5;
	}

	public void setSharePriceTurn5(double sharePriceTurn5) {
		this.sharePriceTurn5 = sharePriceTurn5;
	}

	public double getSharePriceTurn6() {
		return sharePriceTurn6;
	}

	public void setSharePriceTurn6(double sharePriceTurn6) {
		this.sharePriceTurn6 = sharePriceTurn6;
	}

	public double getSharePriceTurn7() {
		return sharePriceTurn7;
	}

	public void setSharePriceTurn7(double sharePriceTurn7) {
		this.sharePriceTurn7 = sharePriceTurn7;
	}

	public double getSharePriceTurn8() {
		return sharePriceTurn8;
	}

	public void setSharePriceTurn8(double sharePriceTurn8) {
		this.sharePriceTurn8 = sharePriceTurn8;
	}

	public double getSharePriceTurn9() {
		return sharePriceTurn9;
	}

	public void setSharePriceTurn9(double sharePriceTurn9) {
		this.sharePriceTurn9 = sharePriceTurn9;
	}

	public double getSharePriceTurn10() {
		return sharePriceTurn10;
	}

	public void setSharePriceTurn10(double sharePriceTurn10) {
		this.sharePriceTurn10 = sharePriceTurn10;
	}

	public int getTempTurnId() {
		return tempTurnId;
	}

	public void setTempTurnId(int tempTurnId) {
		this.tempTurnId = tempTurnId;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}

}
