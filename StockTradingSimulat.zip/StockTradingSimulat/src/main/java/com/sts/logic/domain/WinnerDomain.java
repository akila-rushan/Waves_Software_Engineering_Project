package com.sts.logic.domain;

public class WinnerDomain {

	private int userId;
	private int roundId;
	private String userName;
	private double profit;
	private String State;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getRoundId() {
		return roundId;
	}

	public void setRoundId(int roundId) {
		this.roundId = roundId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public double getProfit() {
		return profit;
	}

	public void setProfit(double profit) {
		this.profit = profit;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

}
