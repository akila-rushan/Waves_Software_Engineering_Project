package com.sts.logic.domain;

public class EventDomain {

	private int eventValue;
	private int eventEnd;

	public int getEventValue() {
		return eventValue;
	}

	public void setEventValue(int eventValue) {
		this.eventValue = eventValue;
	}

	public int getEventEnd() {
		return eventEnd;
	}

	public void setEventEnd(int eventEnd) {
		this.eventEnd = eventEnd;
	}

}
