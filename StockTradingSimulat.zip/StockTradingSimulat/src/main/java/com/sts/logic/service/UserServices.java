package com.sts.logic.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sts.data.entity.Bank;
import com.sts.data.entity.User;
import com.sts.data.repository.BankRepository;
import com.sts.data.repository.UserRepository;

@Service
public class UserServices {

	private UserRepository userRepository;
	private BankRepository bankRepository;

	@Autowired
	public UserServices(UserRepository userRepository, BankRepository bankRepository) {
		super();
		this.userRepository = userRepository;
		this.bankRepository = bankRepository;
	}

	public List<User> allUsers() {

		List<User> users = new ArrayList<>();
		Iterable<User> allUsers = this.userRepository.findAll();
		allUsers.forEach(user -> {
			users.add(user);
		});

		return users;
	}

	// User Register

	public boolean register(String userName, String password, String confirmPassword) {
		if (this.isUser(userName) && this.isPasswordMatch(password, confirmPassword)) {
			this.saveUser(userName, password);
			this.createBankAccount(userName);
			return true;
		} else {
			return false;
		}
	}

	private void saveUser(String userName, String password) {
		User user = new User();
		user.setUserName(userName);
		user.setPassword(password);
		user.setOnline(false);
		this.userRepository.save(user);
	}

	private boolean isUser(String userName) {
		if (this.userRepository.countByUserName(userName) > 0) {
			return false;
		} else {
			return true;
		}
	}

	private boolean isPasswordMatch(String password, String confirmPassword) {
		if (password.equals(confirmPassword)) {
			return true;
		} else {
			return false;
		}
	}

	private void createBankAccount(String userName) {
		User user = this.userRepository.findByUserName(userName);
		Bank bank = new Bank();
		bank.setBankAmount(1000);
		bank.setUser(user);
		this.bankRepository.save(bank);
	}

	// User Login

	public boolean login(String userName, String password) {
		if (!this.isUser(userName) && this.checkPassword(userName, password)) {
			User user = this.userRepository.findByUserName(userName);
			user.setOnline(true);
			this.userRepository.save(user);
			return true;
		} else {
			return false;
		}
	}

	private boolean checkPassword(String userName, String password) {
		User user = new User();
		user = this.userRepository.findPasswordByUserName(userName);
		if (password.equals(user.getPassword())) {
			return true;
		} else {
			return false;
		}
	}

	// User Logout

	public void logout(String userName) {
		User user = this.userRepository.findByUserName(userName);
		user.setOnline(false);
		this.userRepository.save(user);
	}

}
