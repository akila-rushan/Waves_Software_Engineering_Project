package com.sts.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sts.data.entity.User;
import com.sts.logic.domain.RoundUserDomain;
import com.sts.logic.domain.UserBankDomain;
import com.sts.logic.service.DashboardServices;

@RestController
@RequestMapping(value = "/api")
public class DashboardServicesController {

	@Autowired
	private DashboardServices dashboardServices;

	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/user-bank")
	public UserBankDomain getUserBankData(@RequestParam(name = "username") String userName) {
		return this.dashboardServices.getUserBankData(userName);
	}

	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/online_players")
	public List<User> onlinePlayers(@RequestParam(name = "username") String userName) {
		return this.dashboardServices.getPlayersOnline(userName);
	}

	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/rounds-wining-users")
	public List<RoundUserDomain> getRoundsWiningUsers() {
		return this.dashboardServices.getWiningUsers();
	}

}
