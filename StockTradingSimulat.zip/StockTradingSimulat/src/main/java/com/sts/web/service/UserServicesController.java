package com.sts.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sts.data.entity.User;
import com.sts.logic.service.UserServices;

@RestController
@RequestMapping(value = "/api")
public class UserServicesController {

	@Autowired
	private UserServices userServices;

	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/users")
	public List<User> getAllUsers() {
		return this.userServices.allUsers();
	}

	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/register")
	public boolean saveUser(@RequestParam(name = "username") String userName,
			@RequestParam(name = "password") String password,
			@RequestParam(name = "confirmpassword") String confirmPassword) {
		return userServices.register(userName, password, confirmPassword);
	}
	
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/login")
	public boolean login(@RequestParam(name = "username") String userName,
			@RequestParam(name = "password") String password) {
		return userServices.login(userName, password);
	}
	
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/logout")
	public void logout(@RequestParam(name = "username") String userName) {
		userServices.logout(userName);
	}

}
