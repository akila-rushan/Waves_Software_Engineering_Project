package com.sts.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sts.data.entity.Company;
import com.sts.logic.domain.SectorDomain;
import com.sts.logic.service.CompanyServices;

@RestController
@RequestMapping(value = "/api")
public class CompanyServiceController {

	@Autowired
	private CompanyServices companyServices;

	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/companies")
	public List<Company> getCompanies() {
		return this.companyServices.getAllCompany();
	}

	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/companies-group-sector")
	public List<SectorDomain> getCompaniesGroupSector() {
		return this.companyServices.getAllCompaniesGroupSector();
	}

}
