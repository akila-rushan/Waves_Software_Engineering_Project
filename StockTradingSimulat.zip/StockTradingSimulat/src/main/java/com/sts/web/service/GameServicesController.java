package com.sts.web.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sts.logic.domain.GameRunDomain;
import com.sts.logic.domain.TurnDomain;
import com.sts.logic.service.GameServices;

@RestController
@RequestMapping(value = "/api")
public class GameServicesController {

	@Autowired
	private GameServices GameServices;

	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/round-turn-new-values")
	public List<TurnDomain> getTurnNewValues() {
		return this.GameServices.roundTurnsValues();
	}

	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/newRound")
	public int newRound(@RequestParam(value = "username1") String userNames1,
			@RequestParam(value = "username2") String userNames2, @RequestParam(value = "username3") String userNames3,
			@RequestParam(value = "username4") String userNames4) {
		List<String> userNames = new ArrayList<>();
		userNames.add(userNames1);
		userNames.add(userNames2);
		userNames.add(userNames3);
		userNames.add(userNames4);
		return this.GameServices.gameStart(userNames);
	}

	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/run")
	public List<GameRunDomain> run(@RequestParam(value = "tempturn") int tempTurn,
			@RequestParam(value = "username") String userName, @RequestParam(value = "roundid") int roundId,
			@RequestParam(value = "sectorid") int sectorId) {
		return this.GameServices.run(tempTurn, userName, roundId, sectorId);
	}
//	
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/buy-share")
	public boolean buy(@RequestParam(value = "tempturn") int tempTurn,
			@RequestParam(value = "username") String userName, @RequestParam(value = "roundid") int roundId,
			@RequestParam(value = "companyid") int companyId,
			@RequestParam(value = "units") int units) {
		return this.GameServices.buyShares(roundId, companyId, userName, tempTurn, units);
	}
//	
	@CrossOrigin
	@RequestMapping(method = RequestMethod.POST, value = "/sell-share")
	public List<GameRunDomain> sell(@RequestParam(value = "tempturn") int tempTurn,
			@RequestParam(value = "username") String userName, @RequestParam(value = "roundid") int roundId,
			@RequestParam(value = "sectorid") int sectorId) {
		return this.GameServices.run(tempTurn, userName, roundId, sectorId);
	}



}
