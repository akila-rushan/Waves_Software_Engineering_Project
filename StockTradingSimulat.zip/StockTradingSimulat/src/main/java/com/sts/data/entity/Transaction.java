package com.sts.data.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "transaction", catalog = "sts")
public class Transaction implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer transactionId;
	private Bank bank;
	private double transactionAmount;
	private String transactionType;

	public Transaction() {
	}

	public Transaction(Bank bank, double transactionAmount, String transactionType) {
		this.bank = bank;
		this.transactionAmount = transactionAmount;
		this.transactionType = transactionType;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "transaction_id", unique = true, nullable = false)
	public Integer getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "bank_id", nullable = false)
	public Bank getBank() {
		return this.bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	@Column(name = "transaction_amount", nullable = false)
	public double getTransactionAmount() {
		return this.transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	@Column(name = "transaction_type", nullable = false, length = 1)
	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

}
