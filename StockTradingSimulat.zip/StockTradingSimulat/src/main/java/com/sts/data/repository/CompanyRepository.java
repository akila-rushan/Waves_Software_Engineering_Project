package com.sts.data.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sts.data.entity.Company;
import com.sts.data.entity.Sector;

@Repository
public interface CompanyRepository extends CrudRepository<Company, Integer> {
	
	Iterable<Company> findAll();

	Iterable<Company> findBySector(Sector sector);

	Company findByCompanyId(Integer companyId);
	
}
