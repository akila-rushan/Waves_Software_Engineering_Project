package com.sts.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "round", catalog = "sts")
public class Round implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer roundId;
	private Set<RoundUser> roundUsers = new HashSet<RoundUser>(0);
	private Set<Turn> turns = new HashSet<Turn>(0);

	public Round() {
	}

	public Round(Set<RoundUser> roundUsers, Set<Turn> turns) {
		this.roundUsers = roundUsers;
		this.turns = turns;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "round_id", unique = true, nullable = false)
	public Integer getRoundId() {
		return this.roundId;
	}

	public void setRoundId(Integer roundId) {
		this.roundId = roundId;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "round")
	public Set<RoundUser> getRoundUsers() {
		return this.roundUsers;
	}

	public void setRoundUsers(Set<RoundUser> roundUsers) {
		this.roundUsers = roundUsers;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "round")
	public Set<Turn> getTurns() {
		return this.turns;
	}

	public void setTurns(Set<Turn> turns) {
		this.turns = turns;
	}

}
