package com.sts.data.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sts.data.entity.Round;
import com.sts.data.entity.Turn;

@Repository
public interface TurnRepository extends CrudRepository<Turn, Integer> {

	Turn findFirstByOrderByTurnIdDesc();

	Turn findByTurnId(Integer turnId);

	List<Turn> findByRound(Round round);

	Turn findByRoundAndTurnTempId(Round findByRoundId, int tempTurn);

	Turn findByTurnTempIdAndRound(int tempTurn, Round findByRoundId);

}
