package com.sts.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "company", catalog = "sts")
public class Company implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer companyId;
	@JsonIgnore
	private Sector sector;
	private String companyName;
	private double lastStockPrice;
	@JsonIgnore
	private Set<UserTurn> userTurns = new HashSet<UserTurn>(0);
	private Set<TurnCompany> turnCompanies = new HashSet<TurnCompany>(0);

	public Company() {
	}

	public Company(Sector sector, String companyName, double lastStockPrice) {
		this.sector = sector;
		this.companyName = companyName;
		this.lastStockPrice = lastStockPrice;
	}

	public Company(Sector sector, String companyName, double lastStockPrice, Set<UserTurn> userTurns) {
		this.sector = sector;
		this.companyName = companyName;
		this.lastStockPrice = lastStockPrice;
		this.userTurns = userTurns;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "company_id", unique = true, nullable = false)
	public Integer getCompanyId() {
		return this.companyId;
	}

	public void setCompanyId(Integer companyId) {
		this.companyId = companyId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "sector_id", nullable = false)
	public Sector getSector() {
		return this.sector;
	}

	public void setSector(Sector sector) {
		this.sector = sector;
	}

	@Column(name = "company_name", nullable = false, length = 45)
	public String getCompanyName() {
		return this.companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	@Column(name = "last_stock_price", nullable = false)
	public double getLastStockPrice() {
		return this.lastStockPrice;
	}

	public void setLastStockPrice(double lastStockPrice) {
		this.lastStockPrice = lastStockPrice;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "company")
	public Set<UserTurn> getUserTurns() {
		return this.userTurns;
	}

	public void setUserTurns(Set<UserTurn> userTurns) {
		this.userTurns = userTurns;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "company")
	public Set<TurnCompany> getTurnCompanies() {
		return turnCompanies;
	}

	public void setTurnCompanies(Set<TurnCompany> turnCompanies) {
		this.turnCompanies = turnCompanies;
	}

}
