package com.sts.data.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sts.data.entity.Round;

@Repository
public interface RoundRepository extends CrudRepository<Round, Integer> {

	Round findFirstByOrderByRoundIdDesc();

	Round findByRoundId(Integer roundId);

}
