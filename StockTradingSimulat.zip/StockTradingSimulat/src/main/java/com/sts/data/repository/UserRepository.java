package com.sts.data.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sts.data.entity.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {
	
	Iterable<User> findAll();

	User findByUserName(String userName);

	int countByUserName(String userName);

	User findPasswordByUserName(String userName);

	Iterable<User> findByOnline(Boolean online);

}
