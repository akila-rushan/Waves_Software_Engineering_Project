package com.sts.data.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "user_turn", catalog = "sts")
public class UserTurn implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer userTurnId;
	private Company company;
	private Turn turn;
	private User user;
	private double stockPrice;
	private String tradingType;
	private int unit;
	private Boolean sell;

	public UserTurn() {
	}

	public UserTurn(Company company, Turn turn, User user, double stockPrice, String tradingType) {
		this.company = company;
		this.turn = turn;
		this.user = user;
		this.stockPrice = stockPrice;
		this.tradingType = tradingType;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "user_turn_id", unique = true, nullable = false)
	public Integer getUserTurnId() {
		return this.userTurnId;
	}

	public void setUserTurnId(Integer userTurnId) {
		this.userTurnId = userTurnId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "company_id", nullable = false)
	public Company getCompany() {
		return this.company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "turn_id", nullable = false)
	public Turn getTurn() {
		return this.turn;
	}

	public void setTurn(Turn turn) {
		this.turn = turn;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false)
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Column(name = "stock_price", nullable = false)
	public double getStockPrice() {
		return this.stockPrice;
	}

	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}

	@Column(name = "trading_type", nullable = false, length = 1)
	public String getTradingType() {
		return this.tradingType;
	}

	public void setTradingType(String tradingType) {
		this.tradingType = tradingType;
	}

	@Column(name = "units", nullable = false)
	public int getUnit() {
		return unit;
	}

	public void setUnit(int unit) {
		this.unit = unit;
	}

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "sell", nullable = false, columnDefinition = "TINYINT")
	public Boolean getSell() {
		return sell;
	}

	public void setSell(Boolean sell) {
		this.sell = sell;
	}

	

}
