package com.sts.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "sector", catalog = "sts")
public class Sector implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer sectorId;
	private String sectorName;
	private Set<Company> companies = new HashSet<Company>(0);

	public Sector() {
	}

	public Sector(String sectorName) {
		this.sectorName = sectorName;
	}

	public Sector(String sectorName, Set<Company> companies) {
		this.sectorName = sectorName;
		this.companies = companies;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "sector_id", unique = true, nullable = false)
	public Integer getSectorId() {
		return this.sectorId;
	}

	public void setSectorId(Integer sectorId) {
		this.sectorId = sectorId;
	}

	@Column(name = "sector_name", nullable = false, length = 45)
	public String getSectorName() {
		return this.sectorName;
	}

	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "sector")
	public Set<Company> getCompanies() {
		return this.companies;
	}

	public void setCompanies(Set<Company> companies) {
		this.companies = companies;
	}

}
