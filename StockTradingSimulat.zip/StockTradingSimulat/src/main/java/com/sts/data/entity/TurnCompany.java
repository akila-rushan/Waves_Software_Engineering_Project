package com.sts.data.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "turn_company", catalog = "sts")
public class TurnCompany implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private Integer turnCompanyId;
	private Company company;
	private Turn turn;
	private double stockPrice;

	public TurnCompany() {
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	
	@Column(name = "turn_company_id", unique = true, nullable = false)
	public Integer getTurnCompanyId() {
		return turnCompanyId;
	}

	public void setTurnCompanyId(Integer turnCompanyId) {
		this.turnCompanyId = turnCompanyId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "company_id", nullable = false)
	public Company getCompany() {
		return this.company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "turn_id", nullable = false)
	public Turn getTurn() {
		return this.turn;
	}

	public void setTurn(Turn turn) {
		this.turn = turn;
	}

	@Column(name = "stock_price", nullable = false)
	public double getStockPrice() {
		return this.stockPrice;
	}

	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}
	
}
