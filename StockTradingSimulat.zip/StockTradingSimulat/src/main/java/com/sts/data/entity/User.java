package com.sts.data.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "user", catalog = "sts")
public class User implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer userId;
	private String userName;
	private String password;
	private Boolean online;
	@JsonIgnore
	private Set<UserTurn> userTurns = new HashSet<UserTurn>(0);
	@JsonIgnore
	private Set<RoundUser> roundUsers = new HashSet<RoundUser>(0);
	@JsonIgnore
	private Bank bank;

	public User() {
	}

	public User(String userName, String password) {
		this.userName = userName;
		this.password = password;
	}

	public User(String userName, String password, Set<UserTurn> userTurns, Set<RoundUser> roundUsers, Bank banks) {
		this.userName = userName;
		this.password = password;
		this.userTurns = userTurns;
		this.roundUsers = roundUsers;
		this.bank = banks;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "user_id", unique = true, nullable = false)
	public Integer getUserId() {
		return this.userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Column(name = "user_name", nullable = false, length = 45)
	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@Column(name = "password", nullable = false, length = 45)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Type(type = "org.hibernate.type.NumericBooleanType")
	@Column(name = "online", nullable = false, columnDefinition = "TINYINT")
	public Boolean getOnline() {
		return online;
	}

	public void setOnline(Boolean online) {
		this.online = online;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	public Set<UserTurn> getUserTurns() {
		return this.userTurns;
	}

	public void setUserTurns(Set<UserTurn> userTurns) {
		this.userTurns = userTurns;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	public Set<RoundUser> getRoundUsers() {
		return this.roundUsers;
	}

	public void setRoundUsers(Set<RoundUser> roundUsers) {
		this.roundUsers = roundUsers;
	}

	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "user")
	public Bank getBank() {
		return this.bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

}
