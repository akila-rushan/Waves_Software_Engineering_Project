package com.sts.data.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "bank", catalog = "sts")
public class Bank implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer bankId;
	private User user;
	private double bankAmount;
	private Set<Transaction> transactions = new HashSet<Transaction>(0);

	public Bank() {
	}

	public Bank(User user, double bankAmount) {
		this.user = user;
		this.bankAmount = bankAmount;
	}

	public Bank(User user, double bankAmount, Set<Transaction> transactions) {
		this.user = user;
		this.bankAmount = bankAmount;
		this.transactions = transactions;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "bank_id", unique = true, nullable = false)
	public Integer getBankId() {
		return this.bankId;
	}

	public void setBankId(Integer bankId) {
		this.bankId = bankId;
	}

	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false)
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Column(name = "bank_amount", nullable = false)
	public double getBankAmount() {
		return this.bankAmount;
	}

	public void setBankAmount(double bankAmount) {
		this.bankAmount = bankAmount;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "bank")
	public Set<Transaction> getTransactions() {
		return this.transactions;
	}

	public void setTransactions(Set<Transaction> transactions) {
		this.transactions = transactions;
	}

}
