package com.sts.data.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sts.data.entity.Company;
import com.sts.data.entity.Turn;
import com.sts.data.entity.TurnCompany;

@Repository
public interface TurnCompanyRepository extends CrudRepository<TurnCompany, Integer> {

	List<TurnCompany> findByTurn(Turn turn);

	TurnCompany findByTurnAndCompany(Turn findByRoundAndTurnTempId, Company company);

}
