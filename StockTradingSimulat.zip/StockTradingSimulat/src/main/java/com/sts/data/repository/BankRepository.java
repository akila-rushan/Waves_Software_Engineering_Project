package com.sts.data.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sts.data.entity.Bank;
import com.sts.data.entity.User;

@Repository
public interface BankRepository extends CrudRepository<Bank, Integer> {

	Bank findByBankId(Integer id);

	Bank findByUser(User user);

	Bank findByUserUserId(Integer userId);

	
}
