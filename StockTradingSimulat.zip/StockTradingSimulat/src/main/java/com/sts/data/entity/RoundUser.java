package com.sts.data.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "round_user", catalog = "sts")
public class RoundUser implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer roundUserId;
	private Round round;
	private User user;
	private String userState;
	private double boughtValue;
	private double SoldValue;

	public RoundUser() {
	}

	public RoundUser(Round round, User user, String userState) {
		this.round = round;
		this.user = user;
		this.userState = userState;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "round_user_id", unique = true, nullable = false)
	public Integer getRoundUserId() {
		return this.roundUserId;
	}

	public void setRoundUserId(Integer roundUserId) {
		this.roundUserId = roundUserId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "round_id", nullable = false)
	public Round getRound() {
		return this.round;
	}

	public void setRound(Round round) {
		this.round = round;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false)
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Column(name = "user_state", nullable = false, length = 1)
	public String getUserState() {
		return this.userState;
	}

	public void setUserState(String userState) {
		this.userState = userState;
	}

	@Column(name = "bought_value", nullable = false)
	public double getBoughtValue() {
		return boughtValue;
	}

	public void setBoughtValue(double boughtValue) {
		this.boughtValue = boughtValue;
	}

	@Column(name = "sold_value", nullable = false)
	public double getSoldValue() {
		return SoldValue;
	}

	public void setSoldValue(double soldValue) {
		SoldValue = soldValue;
	}

}
