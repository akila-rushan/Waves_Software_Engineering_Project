package com.sts.data.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sts.data.entity.Round;
import com.sts.data.entity.RoundUser;
import com.sts.data.entity.User;

@Repository
public interface RoundUserRepository extends CrudRepository<RoundUser, Integer> {
	
	List<RoundUser> findByUserState(String string);

	List<RoundUser> findByRound(Round findByRoundId);

	RoundUser findByRoundAndUser(Round round, User user);
}
