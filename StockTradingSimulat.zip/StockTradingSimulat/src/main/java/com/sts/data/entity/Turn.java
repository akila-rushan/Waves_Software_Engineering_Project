package com.sts.data.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "turn", catalog = "sts")
public class Turn implements Serializable {
	private static final long serialVersionUID = 1L;

	private Integer turnId;
	private Round round;
	private int turnTempId;
	private Set<UserTurn> userTurns = new HashSet<UserTurn>(0);
	private Set<TurnCompany> turnCompanies = new HashSet<TurnCompany>(0);

	public Turn() {
	}

	public Turn(Round round) {
		this.round = round;
	}

	public Turn(Round round, Set<UserTurn> userTurns) {
		this.round = round;
		this.userTurns = userTurns;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "turn_id", unique = true, nullable = false)
	public Integer getTurnId() {
		return this.turnId;
	}

	public void setTurnId(Integer turnId) {
		this.turnId = turnId;
	}

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "round_id", nullable = false)
	public Round getRound() {
		return this.round;
	}

	public void setRound(Round round) {
		this.round = round;
	}
	
	@Column(name = "turn_temp_id", nullable = false)
	public int getTurnTempId() {
		return turnTempId;
	}

	public void setTurnTempId(int turnTempId) {
		this.turnTempId = turnTempId;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "turn")
	public Set<UserTurn> getUserTurns() {
		return this.userTurns;
	}

	public void setUserTurns(Set<UserTurn> userTurns) {
		this.userTurns = userTurns;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "turn")
	public Set<TurnCompany> getTurnCompanies() {
		return turnCompanies;
	}

	public void setTurnCompanies(Set<TurnCompany> turnCompanies) {
		this.turnCompanies = turnCompanies;
	}
	
	

}
